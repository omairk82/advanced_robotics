#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kf.msg import *

import numpy
import math

#global variable declaration
u=B=x=P=[]

def Matrix2List(matrix):
	#converts numpy matrix type object into a 1D array (compatible with ROS)
	a = numpy.asarray(matrix) #convert matrix to array
	b = a.tolist() #convert array to list
	out = sum(b, []) #neat trick to convet multi-line lists into a single line list - see: http://stackoverflow.com/questions/2961983/convert-multi-dimensional-list-to-a-1d-list-in-python
	return out

def List2Matrix(in_list, row, col):
	#converts list into numpy matrix object of dimension row x col
	a = []; #initialize updated array
	in_list = in_list.tolist()
	for i in range(0,row): #python starts indexing at 0
		while (len(in_list)>0):
			a.append(in_list[0:col]) #grab the col entries for the row i
			del in_list[0:col] #remove corresponding col entries from in_list
	b = numpy.array(a) #convert to numpy array
	out = numpy.matrix(b) #conver to numpy matrix
	return out

class KalmanFilterLinear_Prediction:
	def __init__(self,_A, _B, _x, _P, _Q):
		self.A = _A                      # State transition matrix.
		self.B = _B                      # Control matrix.
		self.current_state_estimate = _x # Initial state estimate.
		self.current_prob_estimate = _P  # Initial covariance estimate.
		self.Q = _Q                      # Estimated error in prediction.
	def GetCurrentState(self):
		return self.current_state_estimate
	def Prediction_Step(self,control_vector):
		#---------------------------Prediction step-----------------------------
		predicted_state_estimate = self.A * self.current_state_estimate + self.B * control_vector
		predicted_prob_estimate = (self.A * self.current_prob_estimate) * numpy.transpose(self.A) + self.Q
		print self.A
		print self.current_state_estimate
		print self.B
		print control_vector    
		print 'predicted_state_estimate:'
		print predicted_state_estimate
		print 'predicted_prob_estimate:'
		print predicted_prob_estimate
		return [predicted_state_estimate, Matrix2List(predicted_prob_estimate)]

def callback2(msg): #will not publish until messages over topic control are received
	global u, B
	if x[2] > 0:
		u, B = List2Matrix(msg.u,P.shape[0],1,), List2Matrix(msg.B,P.shape[0],P.shape[1]) #update global variables
		sendMsg(x, P, u, B) #nominal updates while projectile in air
	else:
		rospy.loginfo('IGNORING!!!!!!')
		u = numpy.matrix([[0],[0],[0],[0]])
		B = List2Matrix(msg.B,P.shape[0],P.shape[1])
	print(rospy.get_name()+" Received updated control vector: ")
	print(u)
	print("Received updated control Matrix: ")
	print(B)
	sendMsg(x, P, u, B) #ignores erroneous control updates from updating y coordinates once project has landed

def callback1(msg):
    global x, P
    x, P = List2Matrix(msg.x,P.shape[0],1), List2Matrix(msg.P,P.shape[0],P.shape[1]) #update global variables
    print(rospy.get_name() + " Received updated state: ")
    print(x)
    print("Received updated covariance: ")
    print(P)

def newStateRx():
    #rospy.init_node('Prediction')
    rospy.Subscriber('update', numpy_msg(update), callback1)
    rospy.Subscriber('control',numpy_msg(ctrl),callback2)
    rospy.spin()

def sendMsg(x, P, u , B):
	filter = KalmanFilterLinear_Prediction(A,B,x,P,Q) #reinitialize KalmanFilter so new states are received
	a = filter.Prediction_Step(u)
	rospy.loginfo ("State Prediction = ")
	rospy.loginfo(a[0])
	rospy.loginfo ("Covariance Prediction = ")
	rospy.loginfo (a[1])
	aa = numpy.array(a[0], dtype=numpy.float32)
	b = numpy.array(a[1], dtype=numpy.float32)
	pub = rospy.Publisher('prediction', numpy_msg(pred),latch=True) #latch =True allows new nodes to pick up last message on this topic - saves from startup lag
	pub.publish(aa,b)
    

if __name__ == '__main__':
    rospy.init_node('Prediction')
    #Set initial values
    timeslice = 0.1 #sec - controls rate of prediction refresh #could base on get time before sleep and after awake -> could calc the duration as the real timeslice ;-)
    muzzle_velocity = 100 # initial speed
    angle = 45 # release angle
    speedX = muzzle_velocity*math.cos(angle*math.pi/180)
    speedY = muzzle_velocity*math.sin(angle*math.pi/180)
    A = numpy.matrix([[1,timeslice,0,0],[0,1,0,0],[0,0,1,timeslice],[0,0,0,1]]) #state transition matrix
    B = numpy.matrix([[0,0,0,0],[0,0,0,0],[0,0,1,0],[0,0,0,1]]) #control matrix
    Q = numpy.zeros(A.shape) #Prediction covariance
    u = numpy.matrix([[0],[0],[0.5*-9.81*timeslice*timeslice],[-9.81*timeslice]]) #Initial control vector, this should be initialized to zero!!! inputs will come from control topic!!! FIX!!!
    initial_state = numpy.matrix([[0],[speedX],[500],[speedY]]) # Initial state estimate.
    P = numpy.eye(4) # Initial covariance estimate.
    sendMsg(initial_state, P, u, B) #to get the chain started
    newStateRx()

