#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kf.msg import *

import numpy

#global variable declaration
y = S = K = []; #innov.msg on topic: innovation
x_pred = P_pred = []; #update.msg on topic: update

def Matrix2List(matrix):
	#converts numpy matrix type object into a 1D array (compatible with ROS)
	a = numpy.asarray(matrix) #convert matrix to array
	b = a.tolist() #convert array to list
	out = sum(b, []) #neat trick to convet multi-line lists into a single line list - see: http://stackoverflow.com/questions/2961983/convert-multi-dimensional-list-to-a-1d-list-in-python
	return out

def List2Matrix(in_list, row, col):
	#converts list into numpy matrix object of dimension row x col
	a = []; #initialize updated array
	in_list = in_list.tolist()
	for i in range(0,row): #python starts indexing at 0
		while (len(in_list)>0):
			a.append(in_list[0:col]) #grab the col entries for the row i
			del in_list[0:col] #remove corresponding col entries from in_list
	b = numpy.array(a) #convert to numpy array
	out = numpy.matrix(b) #conver to numpy matrix
	return out

# Implements a linear Kalman filter.
class KalmanFilterLinear_Update:
	def __init__(self,_H):
		self.H = _H                      # Observation matrix.
	def GetCurrentState(self):
		return self.current_state_estimate
	def Update_Step(self,predicted_state_estimate, kalman_gain, innovation, predicted_prob_estimate):
		#-----------------------------Update step-------------------------------
		self.current_state_estimate = predicted_state_estimate + kalman_gain * innovation
		# We need the size of the matrix so we can make an identity matrix.
		size = predicted_prob_estimate.shape[0]
		# eye(n) = nxn identity matrix.
		self.current_prob_estimate = (numpy.eye(size)-kalman_gain*self.H)*predicted_prob_estimate
		print 'predicted_state_estimate'
		print predicted_state_estimate
		print 'innovation'
		print innovation
		print 'kalman_gain:'
		print kalman_gain
		print 'current_state_estimate:'
		print self.current_state_estimate
		print 'current_prob_estimate:'
		print self.current_prob_estimate
		return [self.current_state_estimate, Matrix2List(self.current_prob_estimate)]

def callback2(msg):
    global x_pred, P_pred
    #update global variables for predicted state
    x_pred, P_pred = List2Matrix(msg.x_pred,H.shape[0],1), List2Matrix(msg.P_pred,H.shape[0],H.shape[1])
    print("I received the predicted state: ")
    print(x_pred)
    print("I received the predicted Covariance: ")
    print(P_pred)

def callback1(msg): #NOTE: Receipt of innovation sets pace of when node Update publishes to topic update
	global y,S,K
	#update global variables for innovation
	y, S, K = List2Matrix(msg.y,H.shape[0],1), List2Matrix(msg.S,H.shape[0],H.shape[1]), List2Matrix(msg.K,H.shape[0],H.shape[1])
	print("I received the innovation: ")
	print(y)
	print("I received the innovation covariance: ")
	print(S)
	print("I received the Kalman Gain: ")
	print(K)
	#call Kalman filter
	a = filter.Update_Step(x_pred,K,y,P_pred)
	rospy.loginfo("State Update= ")
	rospy.loginfo(a[0])
	rospy.loginfo("Covariance Update= ")
	rospy.loginfo(a[1])
	#publish to topic
	pub = rospy.Publisher('update', numpy_msg(update), latch=True)
	aa = numpy.array(a[0], dtype=numpy.float32)
	b = numpy.array(a[1], dtype=numpy.float32)
	pub.publish(aa,b)

def stateRx():
	rospy.init_node('Update')
	rospy.Subscriber('innovation', numpy_msg(innov), callback1)
	print 'here'
	rospy.Subscriber('prediction', numpy_msg(pred), callback2)
	#prevent node closure
	rospy.spin()

if __name__ == '__main__':
    H = numpy.eye(4) #Observation Transformation Matrix
    filter = KalmanFilterLinear_Update(H) #create Kalman Filter Update Class
    stateRx()


