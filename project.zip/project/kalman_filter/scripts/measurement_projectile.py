#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kf.msg import msmt

import numpy
import random
import math

itr = 0

def Matrix2List(matrix):
	#converts numpy matrix type object into a 1D array (compatible with ROS)
	a = numpy.asarray(matrix) #convert matrix to array
	b = a.tolist() #convert array to list
	out = sum(b, []) #neat trick to convet multi-line lists into a single line list - see: http://stackoverflow.com/questions/2961983/convert-multi-dimensional-list-to-a-1d-list-in-python
	return out

def List2Matrix(in_list, row, col):
	#converts list into numpy matrix object of dimension row x col
	a = []; #initialize updated array
	in_list = in_list.tolist()
	for i in range(0,row): #python starts indexing at 0
		while (len(in_list)>0):
			a.append(in_list[0:col]) #grab the col entries for the row i
			del in_list[0:col] #remove corresponding col entries from in_list
	b = numpy.array(a) #convert to numpy array
	out = numpy.matrix(b) #conver to numpy matrix
	return out

class Cannon:
	#--------------------------------VARIABLES----------------------------------
	angle = 45 # The angle from the ground to point the cannon.
	muzzle_velocity = 100 # Muzzle velocity of the cannon.
	gravity = [0,-9.81] # A vector containing gravitational acceleration.
	# The initial velocity of the cannonball
	velocity = [muzzle_velocity*math.cos(angle*math.pi/180), muzzle_velocity*math.sin(angle*math.pi/180)]
	loc = [0,0] # The initial location of the cannonball.
	acceleration = [0,0] # The initial acceleration of the cannonball.
	#---------------------------------METHODS-----------------------------------
	def __init__(self,_timeslice,_noiselevel):
		self.timeslice = _timeslice
		self.noiselevel = _noiselevel
	def add(self,x,y):
		return x + y
	def mult(self,x,y):
		return x * y
	def GetX(self):
		return self.loc[0]
	def GetY(self):
		return self.loc[1]
	def GetXWithNoise(self):
		return random.gauss(self.GetX(),self.noiselevel)
		#return self.GetX() + self.noiselevel #debug help
	def GetYWithNoise(self):
		return random.gauss(self.GetY(),self.noiselevel)
		#return self.GetY() + self.noiselevel #debug help
	def GetXVelocity(self):
		return self.velocity[0]
	def GetYVelocity(self):
		return self.velocity[1]
	# Increment through the next timeslice of the simulation.
	def Step(self):
		if self.loc[1]>0 or self.loc[0]==0:
			print 'Cannon details - start'
			# We're gonna use this vector to timeslice everything.
			timeslicevec = [self.timeslice,self.timeslice]
			# Break gravitational force into a smaller time slice.
			print timeslicevec
			sliced_gravity = map(self.mult,self.gravity,timeslicevec)
			print sliced_gravity	
			# The only force on the cannonball is gravity.
			sliced_acceleration = sliced_gravity
			print sliced_acceleration
			# Apply the acceleration to velocity.
			self.velocity = map(self.add, self.velocity, sliced_acceleration)
			sliced_velocity = map(self.mult, self.velocity, timeslicevec )
			print sliced_velocity
			# Apply the velocity to location.
			self.loc = map(self.add, self.loc, sliced_velocity)
			print self.loc
			print 'Cannon details - end'
			# Cannonballs shouldn't go into the ground.
			if self.loc[1] < 0:
				self.loc[1] = 0
		else: print "IGNORING!!!";

def get_reading(sleep_rate):
	pub = rospy.Publisher('measurement', numpy_msg(msmt))
	rospy.init_node('Cannon')
	#r = rospy.Rate(sleep_rate) 
	while not rospy.is_shutdown():
		newestX = c.GetXWithNoise()
		newestY = c.GetYWithNoise()
		print 'z prior to step'
		print numpy.array([newestX, c.GetXVelocity(), newestY, c.GetYVelocity()], dtype=numpy.float32)
		c.Step(); #cannon progresses dynamics to output measured state
		#try later to make this update dynamically by taking time before and after sleep - FIX by including updated timeslice!!!!
		#velocity measurements do not have error - known analytically for this scenario
		a = numpy.array([c.GetXWithNoise(), c.GetXVelocity(), c.GetYWithNoise(), c.GetYVelocity()], dtype=numpy.float32)
		#a = numpy.array([newestX, c.GetXVelocity(), newestY, c.GetYVelocity()], dtype=numpy.float32)
		b = numpy.array([c.GetX(), c.GetXVelocity(), c.GetY(), c.GetYVelocity()], dtype=numpy.float32)
		rospy.loginfo('measurement vector with noise')
		rospy.loginfo(a)
		rospy.loginfo('measurement vector sans noise')
		rospy.loginfo(b)
		pub.publish(a,b)
		rospy.sleep(sleep_rate)

def Tdebug(sleep_rate): #ONLY FOR DEBUG HELP!
	global itr
	while itr<=1:
		pub = rospy.Publisher('measurement', numpy_msg(msmt), latch=True)
		rospy.init_node('Cannon') 
		newestX = c.GetXWithNoise()
		newestY = c.GetYWithNoise()
		print 'z prior to step'
		print numpy.array([newestX, c.GetXVelocity(), newestY, c.GetYVelocity()], dtype=numpy.float32)
		c.Step(); #cannon progresses dynamics to output measured state
		#velocity measurements do not have error - known analytically for this scenario
		a = numpy.array([newestX, c.GetXVelocity(), newestY, c.GetYVelocity()], dtype=numpy.float32)
		b = numpy.array([c.GetX(), c.GetXVelocity(), c.GetY(), c.GetYVelocity()], dtype=numpy.float32)
		print 'measurement vector with noise'
		print a
		#print 'measurement vector sans noise'
		#print b
		pub.publish(a,b)
		itr+=1
		rospy.sleep(2)
	print "While loop complete!"
	input()


if __name__ == '__main__':
	#rospy.sleep(1) #slight time lag to allow for launch file loading
	timeslice = 0.1 #try later to make this update dynamically by taking time before and after sleep - FIX!!!!
	noiselevel = 30
	c = Cannon(timeslice,noiselevel)
	get_reading(timeslice)
	#get_reading(1) # @1hz repeat - simulated time lapse (different from timeslice) so all parts can stay in sync
	#Tdebug(timeslice)
