#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kalman_trial.msg import *

import numpy

#global variable declaration
y = S = K = []; #innov.msg on topic: innovation
x_pred = P_pred = []; #update.msg on topic: update

# Implements a linear Kalman filter.
class KalmanFilterLinear_Update:
  def __init__(self,_H):
    self.H = _H                      # Observation matrix.
  def GetCurrentState(self):
    return self.current_state_estimate
  def Update_Step(self,predicted_state_estimate, kalman_gain, innovation, predicted_prob_estimate):
    #-----------------------------Update step-------------------------------
    self.current_state_estimate = predicted_state_estimate + kalman_gain * innovation
    # We need the size of the matrix so we can make an identity matrix.
    size = predicted_prob_estimate.shape[0]
    # eye(n) = nxn identity matrix.
    self.current_prob_estimate = (numpy.eye(size)-kalman_gain*self.H)*predicted_prob_estimate
    return [self.current_state_estimate, self.current_prob_estimate]

def callback2(msg):
    global x_pred, P_pred
    rospy.loginfo("I received the predicted state: %f" % (msg.x_pred))
    rospy.loginfo("I received the predicted Covariance: %f" % (msg.P_pred))
    #update global variables for predicted state
    x_pred, P_pred = msg.x_pred, msg.P_pred

def callback1(msg): #NOTE: Receipt of innovation sets pace of when node Update publishes to topic update
    global y,S,K
    rospy.loginfo("I received the innovation: %f" % (msg.y))
    rospy.loginfo("I received the innovation covariance: %f" % (msg.S))
    rospy.loginfo("I received the Kalman Gain: %f" % (msg.K))
    #update global variables for innovation
    y, S, K = msg.y, msg.S, msg.K
    #call Kalman filter
    a = filter.Update_Step(x_pred,K,y,P_pred)
    rospy.loginfo("Current State = %f" % a[0])
    rospy.loginfo("Current Covariance = %f" % a[1])
    #publish to topic
    pub = rospy.Publisher('update', numpy_msg(update))
    aa = numpy.array(a[0], dtype=numpy.float32)
    b = numpy.array(a[1], dtype=numpy.float32)
    pub.publish(aa,b)

def stateRx():
    rospy.init_node('Update')
    rospy.Subscriber('innovation', numpy_msg(innov), callback1)
    rospy.Subscriber('prediction', numpy_msg(pred), callback2)
    #prevent node closure
    rospy.spin()

if __name__ == '__main__':
    H = numpy.matrix([1]) #should come from parameter
    filter = KalmanFilterLinear_Update(H) #create Kalman Filter Update Class
    stateRx()


