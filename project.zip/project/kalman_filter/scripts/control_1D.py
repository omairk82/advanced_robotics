#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kalman_trial.msg import *

import numpy

class ControlSim:
  def __init__(self):
    '''
    self.A = _A                      # State transition matrix.
    self.B = _B                      # Control matrix.
    self.current_state_estimate = _x # Initial state estimate.
    self.current_prob_estimate = _P  # Initial covariance estimate.
    self.Q = _Q                      # Estimated error in prediction.
    '''
  def DetermineResponse(self):
    return self.current_state_estimate
  def GetControlVector(self):
    return numpy.matrix([0])
  def GetControlMatrix(self):
    return numpy.matrix([0])

def callback1(msg):
    rospy.loginfo("I received the state update: %f" % (msg.x))
    rospy.loginfo("I received the covariance update: %f" % (msg.P))
    #calculate control response
    a, b = control.GetControlVector(), control.GetControlMatrix()
    rospy.loginfo("Control vector update = %f" % a[0])
    rospy.loginfo("Control Matrix update = %f" % b[0])
    #publish to topic
    pub = rospy.Publisher('control', numpy_msg(ctrl))
    aa = numpy.array(a[0], dtype=numpy.float32)
    bb = numpy.array(b[0], dtype=numpy.float32)
    pub.publish(aa,b)

def stateRx():
    rospy.init_node('Control')
    rospy.Subscriber('update', numpy_msg(update), callback1)
    #prevent node closure
    rospy.spin()

if __name__ == '__main__':
    control = ControlSim() #create ControlSim Object
    stateRx()

