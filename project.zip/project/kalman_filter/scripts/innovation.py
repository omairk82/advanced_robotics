#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kf.msg import *

import numpy

#global variable declaration
z = []; #msmt.msg/msmt on topic: measurement
x_pred = P_pred = []; #pred.msg on topic: prediction

def Matrix2List(matrix):
	#converts numpy matrix type object into a 1D array (compatible with ROS)
	a = numpy.asarray(matrix) #convert matrix to array
	b = a.tolist() #convert array to list
	out = sum(b, []) #neat trick to convet multi-line lists into a single line list - see: http://stackoverflow.com/questions/2961983/convert-multi-dimensional-list-to-a-1d-list-in-python
	return out

def List2Matrix(in_list, row, col):
	#converts list into numpy matrix object of dimension row x col
	a = []; #initialize updated array
	in_list = in_list.tolist()
	for i in range(0,row): #python starts indexing at 0
		while (len(in_list)>0):
			a.append(in_list[0:col]) #grab the col entries for the row i
			del in_list[0:col] #remove corresponding col entries from in_list
	b = numpy.array(a) #convert to numpy array
	out = numpy.matrix(b) #conver to numpy matrix
	return out

# Implements a linear Kalman filter.
class KalmanFilterLinear_Innovation:
	def __init__(self, _H, _R):
		self.H = _H                      # Observation matrix.
		self.R = _R                      # Estimated error in measurements.
	def GetCurrentState(self):
		return self.current_state_estimate
	def Observation_Step(self,measurement_vector, predicted_state_estimate, predicted_prob_estimate):
		#--------------------------Observation step-----------------------------
		#innovation = numpy.matrix(measurement_vector) - (self.H)*numpy.matrix(predicted_state_estimate)
		innovation = measurement_vector - (self.H)*predicted_state_estimate
		innovation_covariance = self.H*predicted_prob_estimate*numpy.transpose(self.H) + self.R
		print 'HERE!'
		print measurement_vector
		print self.H
		print predicted_prob_estimate
		print numpy.transpose(self.H)
		print self.R
		print 'innovation:'
		print innovation
		print 'innovation_covariance:'
		print innovation_covariance

		kalman_gain = predicted_prob_estimate * numpy.transpose(self.H) * numpy.linalg.inv(innovation_covariance)
		print 'kalman_gain:'
		print kalman_gain
		return [innovation,Matrix2List(innovation_covariance),Matrix2List(kalman_gain)]

def callback2(msg):
	global x_pred, P_pred
	x_pred, P_pred = List2Matrix(msg.x_pred,H.shape[0],1), List2Matrix(msg.P_pred,H.shape[0],H.shape[1])
	print("I received the predicted state: ")
	print(x_pred)
	print("I received the predicted covariance: ")
	print(P_pred)

def callback1(msg): #NOTE: Kalman Filter refresh rate is determined by the pace of the measurement topic
	global z
	z = List2Matrix(msg.msmt,H.shape[0],1) #update global variable for measurement
	print(rospy.get_name() + " I received the measurement: ")
	print(z)
	print(rospy.get_name() + " I received the true measurement: ")
	print(msg.true_msmt)
	print("Using predicted state: ")
	print(x_pred)
	print("Using predicted covariance: ")
	print(P_pred)
	#publish data to topic innovation
	a = filter.Observation_Step(z,x_pred, P_pred)
	rospy.loginfo("Innovation = ")
	rospy.loginfo(a[0])
	rospy.loginfo("Innovation Covariance = ")
	rospy.loginfo(a[1])
	rospy.loginfo("Kalman Gain = ")
	rospy.loginfo(a[2])
	pub = rospy.Publisher('innovation', numpy_msg(innov), latch=True)
	aa = numpy.array(a[0], dtype=numpy.float32)
	b = numpy.array(a[1], dtype=numpy.float32)
	c = numpy.array(a[2], dtype=numpy.float32)
	pub.publish(aa,b,c)

def msmtRx():
	rospy.init_node('Innovation')
	rospy.Subscriber('prediction', numpy_msg(pred), callback2)
	rospy.Subscriber('measurement', numpy_msg(msmt), callback1)
	#keep node from shutting down
	rospy.spin()

if __name__ == '__main__':
    H = numpy.eye(4) #Observation Transformation Matrix
    R = numpy.eye(4)*0.2 #Measurement Covariance
    filter = KalmanFilterLinear_Innovation(H, R) #create Kalman Filter Innovation Class
    msmtRx()


