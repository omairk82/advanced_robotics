#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kalman_trial.msg import *

import numpy

#global variable declaration
u=B=x=P=[]

class KalmanFilterLinear_Prediction:
  def __init__(self,_A, _B, _x, _P, _Q):
    self.A = _A                      # State transition matrix.
    self.B = _B                      # Control matrix.
    self.current_state_estimate = _x # Initial state estimate.
    self.current_prob_estimate = _P  # Initial covariance estimate.
    self.Q = _Q                      # Estimated error in prediction.
  def GetCurrentState(self):
    return self.current_state_estimate
  def Prediction_Step(self,control_vector):
    #---------------------------Prediction step-----------------------------
    predicted_state_estimate = self.A * self.current_state_estimate + self.B * control_vector
    predicted_prob_estimate = (self.A * self.current_prob_estimate) * numpy.transpose(self.A) + self.Q
    return [predicted_state_estimate, predicted_prob_estimate]

def callback2(msg): #will not publish until messages over topic control are received
    rospy.loginfo(rospy.get_name()+" Received control vector: %f" % (msg.u))
    rospy.loginfo("Received control Matrix: %f" % (msg.B))
    u, B = msg.u, msg.B #update global variables
    sendMsg(x, P, u, B)

def callback1(msg):
    global x, P
    rospy.loginfo(rospy.get_name()+" Received new state: %f" % (msg.x))
    rospy.loginfo("Received new covariance: %f" % (msg.P))
    x, P = msg.x, msg.P #update global variables

def newStateRx():
    #rospy.init_node('Prediction')
    rospy.Subscriber('update', numpy_msg(update), callback1)
    rospy.Subscriber('control',numpy_msg(ctrl),callback2)
    rospy.spin()

def sendMsg(x, P, u , B):
    filter = KalmanFilterLinear_Prediction(A,B,x,P,Q) #reinitialize KalmanFilter so new states are received
    a = filter.Prediction_Step(numpy.matrix([0])); #Fixed u for now, but should come over a message
    print "State Prediction = %f" % a[0]
    print "Covariance Prediction = %f" % a[1]
    aa = numpy.array(a[0], dtype=numpy.float32)
    b = numpy.array(a[1], dtype=numpy.float32)
    pub = rospy.Publisher('prediction', numpy_msg(pred),latch=True) #latch =True allows new nodes to pick up last message on this topic - saves from startup lag
    pub.publish(aa,b)
    

if __name__ == '__main__':
    rospy.init_node('Prediction')
    #Set initial values
    A = numpy.matrix([1])
    B = numpy.matrix([0])
    Q = numpy.matrix([0.00001])
    u = numpy.matrix([0])
    xhat = numpy.matrix([3]) # Initial state estimate.
    P = numpy.matrix([1]) # Initial covariance estimate.
    sendMsg(xhat, P, u, B) #to get the chain started
    newStateRx()

