#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kf.msg import *

import numpy
import math

#global declaration
state = measure = truth = []
rowdim = 4-1; #number of state variables

def List2Matrix(in_list, row, col):
	#converts list into numpy matrix object of dimension row x col
	a = []; #initialize updated array
	in_list = in_list.tolist()
	for i in range(0,row): #python starts indexing at 0
		while (len(in_list)>0):
			a.append(in_list[0:col]) #grab the col entries for the row i
			del in_list[0:col] #remove corresponding col entries from in_list
	b = numpy.array(a) #convert to numpy array
	out = numpy.matrix(b) #conver to numpy matrix
	return out

def Matrix2List(matrix):
	#converts numpy matrix type object into a 1D array (compatible with ROS)
	a = numpy.asarray(matrix) #convert matrix to array
	b = a.tolist() #convert array to list
	out = sum(b, []) #neat trick to convet multi-line lists into a single line list - see: http://stackoverflow.com/questions/2961983/convert-multi-dimensional-list-to-a-1d-list-in-python
	return out

# Vector Analysis.
class VectorAnalysis:
	def __init__(self):
		self.R = numpy.zeros(3) #vector magnitude
		self.T = numpy.zeros(3) #vector orientation
		#global vectors = [x, xdot, y, ydot]
	def GetVectorMagnitude(self):
		self.state = state
		self.msmt= measure
		self.truth = truth
		self.R[0] = float(math.sqrt(self.state[0]**2 + self.state[2]**2)) #state
		self.R[1] = float(math.sqrt(self.msmt[0]**2 + self.msmt[2]**2)) #msmt
		self.R[2] = float(math.sqrt(self.truth[0]**2 + self.truth[2]**2)) #truth
		return [self.R]
	def GetVectorOrientation(self):
		self.T[0] = float(math.atan(self.state[2]/self.state[0])) #state
		self.T[1] = float(math.atan(self.msmt[2]/self.msmt[0])) #msmt
		self.T[2] = float(math.atan(self.truth[2]/self.truth[0])) #truth
		return [self.T]

def callback2(msg):
	global measure, truth
	print msg.msmt
	print msg.true_msmt
	#update global variables for measurement
	measure, truth = List2Matrix(msg.msmt,rowdim,1), List2Matrix(msg.true_msmt,rowdim,1)
	print("I received the measurements: ")
	print(measure)
	print("I received the true measurements: ")
	print(truth)

def callback1(msg): #NOTE: Receipt of state update sets pace of when node listener publishes to topic
	global state
	#update global variables for innovation
	state = List2Matrix(msg.x,rowdim,1)
	print("I received the state updates: ")
	print(state)
	#call Kalman filter
	a = va.GetVectorMagnitude()
	b = va.GetVectorOrientation()
	print("Vector Magnitude= ")
	print(a)
	print("Vector Orientation= ")
	print(b)
	#publish to topic
	pub = rospy.Publisher('vector_analysis', numpy_msg(rtheta))
	aa = numpy.array(a[0], dtype=numpy.float32)
	bb = numpy.array(b[0], dtype=numpy.float32)
	pub.publish(aa,bb)

def stateRx():
	rospy.init_node('VectorAnalysis')
	rospy.Subscriber('measurement', numpy_msg(msmt), callback2)
	rospy.Subscriber('update', numpy_msg(update), callback1)
	#prevent node closure
	rospy.spin()

if __name__ == '__main__':
	va = VectorAnalysis()
	stateRx()
