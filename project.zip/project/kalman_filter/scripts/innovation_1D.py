#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kalman_trial.msg import *

import numpy

#global variable declaration
z = []; #msmt.msg/msmt on topic: measurement
x_pred = P_pred = []; #pred.msg on topic: prediction

# Implements a linear Kalman filter.
class KalmanFilterLinear_Innovation:
  def __init__(self, _H, _R):
    self.H = _H                      # Observation matrix.
    self.R = _R                      # Estimated error in measurements.
  def GetCurrentState(self):
    return self.current_state_estimate
  def Observation_Step(self,measurement_vector, predicted_state_estimate, predicted_prob_estimate):
    #--------------------------Observation step-----------------------------
    innovation = measurement_vector - self.H*predicted_state_estimate
    innovation_covariance = self.H*predicted_prob_estimate*numpy.transpose(self.H) + self.R
    kalman_gain = predicted_prob_estimate * numpy.transpose(self.H) * numpy.linalg.inv(innovation_covariance)
    return [innovation,innovation_covariance,kalman_gain]

def callback2(msg):
    global x_pred, P_pred
    x_pred, P_pred = msg.x_pred, msg.P_pred
    rospy.loginfo("I received the predicted state: %f" % (x_pred))
    rospy.loginfo("I received the predicted covariance: %f" % (P_pred))

def callback1(msg): #NOTE: Kalman Filter refresh rate is determined by the pace of the measurement topic
    global z
    rospy.loginfo(rospy.get_name() + " I received the measurement: %f" % (msg.msmt))
    z = msg.msmt #update global variable for measurement
    rospy.loginfo("Using predicted state: %f" % (x_pred))
    rospy.loginfo("Using predicted covariance: %f" % (P_pred))
    #publish data to topic innovation
    a = filter.Observation_Step(z,float(x_pred), float(P_pred)) #float needed for single variable case
    rospy.loginfo("Innovation = %f" % a[0])
    rospy.loginfo("Innovation Covariance = %f" % a[1])
    rospy.loginfo("Kalman Gain = %f" % a[2])
    pub = rospy.Publisher('innovation', numpy_msg(innov))
    aa = numpy.array(a[0], dtype=numpy.float32)
    b = numpy.array(a[1], dtype=numpy.float32)
    c = numpy.array(a[2], dtype=numpy.float32)
    pub.publish(aa,b,c)

def msmtRx():
    rospy.init_node('Innovation')
    rospy.Subscriber('prediction', numpy_msg(pred), callback2)
    rospy.Subscriber('measurement', numpy_msg(msmt), callback1)
    #keep node from shutting down
    rospy.spin()

if __name__ == '__main__':
    H = numpy.matrix([1])
    R = numpy.matrix([0.1])
    filter = KalmanFilterLinear_Innovation(H, R) #create Kalman Filter Innovation Class
    msmtRx()


