#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kalman_trial.msg import msmt

import numpy
import random

class Voltmeter:
  def __init__(self,_truevoltage,_noiselevel):
    self.truevoltage = _truevoltage
    self.noiselevel = _noiselevel
  def GetVoltage(self):
    return self.truevoltage
  def GetVoltageWithNoise(self):
    return random.gauss(self.GetVoltage(),self.noiselevel)

def get_reading(sleep_rate):
    pub = rospy.Publisher('measurement', numpy_msg(msmt))
    rospy.init_node('Voltmeter')
    r = rospy.Rate(sleep_rate) 
    while not rospy.is_shutdown():
        a = numpy.array([voltmeter.GetVoltageWithNoise()], dtype=numpy.float32)
        b = numpy.array([voltmeter.GetVoltage()], dtype=numpy.float32)
        pub.publish(a,b)
        r.sleep()

if __name__ == '__main__':
    voltmeter = Voltmeter(1.25,0.25)
    get_reading(1.0/2) # @1hz repeat
