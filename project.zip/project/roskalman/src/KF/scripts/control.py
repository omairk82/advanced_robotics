#!/usr/bin/env python

import rospy
from rospy.numpy_msg import numpy_msg
from kf.msg import *

import numpy

def Matrix2List(matrix):
	#converts numpy matrix type object into a 1D array (compatible with ROS)
	a = numpy.asarray(matrix) #convert matrix to array
	b = a.tolist() #convert array to list
	out = sum(b, []) #neat trick to convet multi-line lists into a single line list - see: http://stackoverflow.com/questions/2961983/convert-multi-dimensional-list-to-a-1d-list-in-python
	return out

def List2Matrix(in_list, row, col):
	#converts list into numpy matrix object of dimension row x col
	a = []; #initialize updated array
	in_list = in_list.tolist()
	for i in range(0,row): #python starts indexing at 0
		while (len(in_list)>0):
			a.append(in_list[0:col]) #grab the col entries for the row i
			del in_list[0:col] #remove corresponding col entries from in_list
	b = numpy.array(a) #convert to numpy array
	out = numpy.matrix(b) #conver to numpy matrix
	return out

class ControlSim:
	def __init__(self):
		None
	def DetermineResponse(self):
		return self.current_state_estimate
	def GetControlVector(self, timeslice):
		#adds acceleration to the kinematic equations.
		control_vector = numpy.matrix([[0],[0],[0.5*-9.81*timeslice*timeslice],[-9.81*timeslice]])
		return control_vector
	def GetControlMatrix(self):
		control_matrix = numpy.matrix([[0,0,0,0],[0,0,0,0],[0,0,1,0],[0,0,0,1]])
		return Matrix2List(control_matrix)

def callback1(msg):
    print("Trigger: I received new messges from the update topic")
    #calculate control response
    a, b = control.GetControlVector(timeslice), control.GetControlMatrix()
    rospy.loginfo("Control vector update = ")
    rospy.loginfo(a)
    rospy.loginfo("Control Matrix update = ")
    rospy.loginfo(b)
    #publish to topic
    pub = rospy.Publisher('control', numpy_msg(ctrl),latch=True)
    aa = numpy.array(a, dtype=numpy.float32)
    bb = numpy.array(b, dtype=numpy.float32)
    pub.publish(aa,bb)

def stateRx():
    rospy.init_node('Control')
    rospy.Subscriber('update', numpy_msg(update), callback1)
    #prevent node closure
    rospy.spin()

if __name__ == '__main__':
	timeslice = 0.1 #sec - controls rate of prediction refresh #could base on get time before sleep and after awake -> could calc the duration as the real timeslice ;-)
	control = ControlSim() #create ControlSim Object
	stateRx()

