#!/usr/bin/env zsh
# generated from catkin/cmake/templates/setup.zsh.in

CATKIN_SHELL=zsh
emulate sh # emulate POSIX
. "/home/parallels/roskalman/devel/setup.sh"
emulate zsh # back to zsh mode
