#!/usr/bin/env bash
# generated from catkin/cmake/templates/setup.bash.in

CATKIN_SHELL=bash
. "/home/parallels/roskalman/devel/setup.sh"
